package com.aplicatiecursant;

import java.util.Scanner;

public class Cursant {
    private StringBuffer prenume = new StringBuffer("");
    private StringBuffer nume = new StringBuffer("");
    private int varsta;
    private String IDCursant;
    private String cursuri = "";
    private int dePlataCursant = 0;
    private static int id = 100;
    //constanta
    private static final int pretCurs = 100;

    //Constructor1: introducere nume cursant si varsta
    public Cursant(String nume, String prenume, int varsta){
        this.prenume.append(nume);
        this.nume.insert(0,prenume);
        this.varsta = varsta;

        setIDCursant();
    }
    //Constructor 2
    public Cursant(String nume, String prenume, int varsta, String cursuri, int dePlataCursant){
        this.nume.append(nume);
        this.prenume.append(prenume);
        this.varsta = varsta;
        setIDCursant();
        this.cursuri = cursuri;
        this.dePlataCursant = dePlataCursant;
    }

    //get nume cursant
    public String getNume(){
        return this.nume.toString();
    }

    //get prenume cursant
    public String getPrenume(){
        return this.prenume.toString();
    }

    //get varsta cursant
    public String getVarsta(){
        return String.valueOf(this.varsta);
    }

    //Generare ID cursant
    private void setIDCursant(){
        //varsta + id
        this.id++;
        this.IDCursant =  this.varsta + "" + this.id;
    }

    //returneaza ID cursant
    public String getIDCursant(){
        return this.IDCursant;
    }

    //Inscriere la cursuri
    public void inscriereCurs(String curs, int n){
        this.cursuri = curs;
        this.dePlataCursant = n * this.pretCurs;
    }

    //Vezi balanta cont cursant
    public int getBalanta(){
        if (dePlataCursant > 0) {
            return this.dePlataCursant;
        }
        else if (dePlataCursant <0){
            return -this.dePlataCursant;
        }
        else {
            return 0;
        }
    }

    //returneaza cursurile la care participa cursantul
    public String getCursuri(){
        return this.cursuri;
    }

    //Plateste taxa curs
    public void platesteCurs(int plata){
        this.dePlataCursant = getBalanta();
        this.dePlataCursant = this.dePlataCursant - plata;
        this.dePlataCursant = getBalanta();
    }

    //Vezi status cursant
    public String toString(){
        String s = new String();
        if(this.dePlataCursant <= 0) {
            s = "Nume: " + this.prenume + " " + this.nume +
                    "\n Varsta: " + this.varsta +
                    "\n ID Cursant: " + this.IDCursant +
                    "\nParticipa la cursurile: " + this.cursuri +
                    "\nDe plata cursant: LEI " + this.dePlataCursant;
        }
        else {
            s = "Nume: " + this.prenume + " " + this.nume +
                    "\n Varsta: " + this.varsta +
                    "\n ID Cursant: " + this.IDCursant +
                    "\nParticipa la cursurile: " + this.cursuri +
                    "\nSold cursant: LEI " + this.dePlataCursant;
        }
        return s;
    }
}
